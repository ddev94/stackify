import { defineStackifyConfig } from "@stackify/core";
export default defineStackifyConfig({
  name: "MyStackifyProject",
});
