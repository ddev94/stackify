import { defineStackifyConfig } from "stackify-core";
export default defineStackifyConfig({
  name: "stackify-app-vite-react",
  server: {
    url: "http://103.82.27.64/platform",
  }
});
