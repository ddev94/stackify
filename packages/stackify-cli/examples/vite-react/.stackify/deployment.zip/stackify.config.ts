import { defineStackifyConfig } from "@stackify/core";
export default defineStackifyConfig({
  name: "stackify-app-vite-react",
});
